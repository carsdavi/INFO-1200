name="Olivia Trujillo"
print(f"name: {name}")
phone = 801234322
print(f”phone: {phone}”)

name = "Zachary Wood"
print(f"name: {name}")
phone = 8018759764
print(phone)
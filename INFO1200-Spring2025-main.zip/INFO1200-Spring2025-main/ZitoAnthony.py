name="Anthony Zito"
print(f"name: {name}")
phone="5551234567
print(f"phone: {phone}")

name="Joaquin Kahnlein"
print(f"name: {name}")
phone= 8017067486
print(f"phone: {phone}")

name="Kynan Sigua"
phone="1234567890"
print(f"name: {name}")
print(f"phone: {1234567890}")
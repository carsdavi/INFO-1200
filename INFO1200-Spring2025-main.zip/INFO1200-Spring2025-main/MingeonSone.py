name="Mingeon Sone"
print(f"name: {name}")
FavBk="Stoner"
print(f"My favorite book: {FavBk}")

name="Kory Anderson"
print(f"name: {name}")
phone=3852069113
print(phone)
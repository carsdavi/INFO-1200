name="Saleem Baig"
FavGame="Persona 5"
print(f"name: {name}")
print(f"Favorite Game: {FavGame}")
